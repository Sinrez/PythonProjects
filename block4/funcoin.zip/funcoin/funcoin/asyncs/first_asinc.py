import time

def notification():
    time.sleep(10)
    print("Созвон через 10 минут!")


def main():
    notification()
    print("Разговариваем с коллегой")
    print("Едим")

main()